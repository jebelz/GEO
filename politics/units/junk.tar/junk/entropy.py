## \namespace geo.politics.units.entropy
# <a href="http://en.wikipedia.org/wiki/Entropy">Entropy</a>

from ._entropy import *

