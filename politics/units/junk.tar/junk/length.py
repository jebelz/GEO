"""Length"""
## \namespace geo.politics.units.length
# <a href="http://en.wikipedia.org/wiki/Length">length</a>.
from ._length import *

