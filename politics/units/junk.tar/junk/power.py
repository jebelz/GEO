"""Power"""
## \namespace geo.politics.units.power
# <a href="http://en.wikiepedia.org/wiki/Power">Power</a>.
from ._power import *

