## \namespace geo.politics.units.angle
# <a href="http://en.wikipedia.org/wiki/Angle">Angle</a>.
