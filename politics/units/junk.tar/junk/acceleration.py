"""Acceleration"""
## \namespace geo.politics.units.acceleration Acceleration Wrapper
from ._acceleration import *


