"""Freq."""
## \namespace geo.politics.units.frequency Hz
from ._frequency import *
