"""Time"""
## \namespace geo.politics.units.times
# <a href="http://en.wikipedia.org/wiki/Time">Time</a>
from ._times import *



