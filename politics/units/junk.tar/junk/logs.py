## \namespace geo.politics.units.logs_
# <a href="http://en.wikipedia.org/wiki/Logarithmic_scale#Logarithmic_unit">
# Logrithmic units</a>

from ._logs import *

