"""Speed"""
## \namespace geo.politics.units.speed
# <a href="http://en.wikipedia.org/wiki/Speed">Speed</a>
from ._speed import *

