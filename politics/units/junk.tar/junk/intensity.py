"""Intensity"""
## \namespace geo.politics.units.intensity
# <a href="http://en.wikipedia.org/wiki/Intensity_(physics)">Intensity<a>
# 
from ._intensity import *

