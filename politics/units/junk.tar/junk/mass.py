"""mass"""
## \namespace geo.politics.units.mass
# <a href="http://en.wikipedia.org/wiki/Mass">Mass</a>
from ._mass import *

