"""Force"""
## \namespace geo.politics.units.force
#<a href="http://en.wikipedia.org/wiki/Force">Force</a>
from ._force import *

