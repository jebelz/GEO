"""Area"""
## \namespace geo.politics.units.area
# <a href="http://en.wikipedia.org/wiki/Area">area</a>
from ._area import *
