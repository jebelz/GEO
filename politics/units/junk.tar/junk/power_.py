"""Power"""
## \namespace geo.politics.units.power_
# <a href="http://en.wikiepedia.org/wiki/Power">Power</a>.
from ._bases import *

