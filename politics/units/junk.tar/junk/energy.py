"""Energy"""
## \namespace geo.politics.units.energy
# <a href="http://en.wikipedia.org/wiki/Energy">Energy</a>.
from ._energy import *

